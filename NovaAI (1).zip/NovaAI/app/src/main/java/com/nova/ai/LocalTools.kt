package com.nova.ai

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/** Instant offline helpers (no internet, no waiting). Used by the voice router and the Terminal. */
object LocalTools {
    private val jokes = listOf(
        "टीचर ने पूछा: पानी में कौन सी चीज़ डूबती नहीं? पप्पू बोला: मैडम, मछली! 😄",
        "पति: आज खाने में क्या बनाओगी? पत्नी: जो तुम्हें आसान लगे। पति: तो फिर ऑर्डर कर दो! 😂",
        "मोबाइल में 1% बैटरी थी। मैं बोला: बस एक ज़रूरी मैसेज भेजना है। मोबाइल बोला: मैं भी बहुत ज़रूरी हूँ, बंद हो रहा हूँ! 🔋",
        "बच्चा: पापा, इंटरनेट इतना धीमा क्यों है? पापा: बेटा, वो भी सोमवार से घबराता है। 😅",
        "दोस्त: तू इतना थका हुआ क्यों लग रहा है? मैं: रात भर सपने में परीक्षा देता रहा, नंबर अभी तक नहीं आए। 😴",
        "डॉक्टर: आपको आराम की ज़रूरत है। मरीज़: पर आराम करने का टाइम कहाँ है? डॉक्टर: मोबाइल बंद करके देखो। मरीज़: कुछ और बताइए! 📵"
    )
    private val shayari = listOf(
        "चाँद से कह दो आज ज़रा देर से निकले, मेरे दोस्त की हँसी अभी बाकी है। 🌙",
        "रास्ते मुश्किल हों तो क्या, मंज़िल को भी तो तुम्हारा इंतज़ार है।",
        "हौसले की एक चिंगारी काफ़ी है, अँधेरे को हराने के लिए। 🔥",
        "कुछ बातें लफ़्ज़ों में नहीं आतीं, बस दिल से दिल तक जाती हैं। 💙",
        "आज की थकान कल की मुस्कान बनेगी, बस चलते रहना।",
        "तेरी याद आई तो चाय भी मीठी लगी, यादों की चीनी बड़ी कमाल है। ☕"
    )
    private val quotes = listOf(
        "छोटे-छोटे कदम भी एक दिन मंज़िल तक पहुँचा देते हैं।",
        "आज का काम कल पर मत छोड़ो, कल के पास अपना काम है।",
        "गलतियाँ इस बात का सबूत हैं कि तुमने कोशिश की।",
        "मेहनत का फल देर से मिलता है, पर मीठा मिलता है।",
        "खुद पर भरोसा रखो, बाकी सब रास्ते में मिल जाएगा।",
        "थककर रुक जाओ तो आराम करो, पर हार मानकर नहीं।"
    )

    private val lenFactor = mapOf("km" to 1000.0, "m" to 1.0, "cm" to 0.01, "mile" to 1609.344, "ft" to 0.3048, "inch" to 0.0254)
    private val massFactor = mapOf("kg" to 1.0, "lb" to 0.45359237, "g" to 0.001)

    private fun unit(u: String): String? = when (u) {
        "km", "kilometer", "kilometers", "kilometre", "kilometres" -> "km"
        "m", "meter", "meters", "metre", "metres" -> "m"
        "cm", "centimeter", "centimeters" -> "cm"
        "mile", "miles" -> "mile"
        "ft", "feet", "foot" -> "ft"
        "inch", "inches" -> "inch"
        "kg", "kilo", "kilos", "kilogram", "kilograms" -> "kg"
        "lb", "lbs", "pound", "pounds" -> "lb"
        "g", "gram", "grams" -> "g"
        "c", "celsius" -> "c"
        "f", "fahrenheit" -> "f"
        else -> null
    }

    fun run(ctx: Context, t: String, name: String, prefs: Prefs): String? {
        // ---- dice, coin, random ----
        if (t in setOf("dice", "roll dice", "dice roll", "pasa phenko", "पासा फेंको", "पासा फेंक")) {
            return "पासा गिरा: " + Random.nextInt(1, 7) + " 🎲"
        }
        if (t in setOf("coin", "flip coin", "toss", "heads or tails", "सिक्का उछालो", "सिक्का फेंको")) {
            return if (Random.nextBoolean()) "छाप (Heads) 🪙" else "पट (Tails) 🪙"
        }
        Regex("^(?:random|rand|रैंडम) (\\d+) (\\d+)$").find(t)?.let {
            val a = it.groupValues[1].toInt()
            val b = it.groupValues[2].toInt()
            if (b >= a) return "रैंडम नंबर: " + Random.nextInt(a, b + 1) + " 🎯"
        }

        // ---- date and time ----
        if (t in setOf("time", "what time is it", "samay kya hua", "time kya hua", "अभी कितने बजे हैं", "कितने बजे हैं", "समय क्या हुआ", "टाइम क्या हुआ")) {
            return "अभी " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()) + " बजे हैं ⏰"
        }
        if (t in setOf("date", "today date", "aaj ki date", "आज की तारीख", "आज कौन सा दिन है", "aaj kaun sa din hai", "day")) {
            return "आज " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale("hi", "IN")).format(Date()) + " है 📅"
        }

        // ---- phone status ----
        if (t in setOf("battery", "battery status", "battery kitni hai", "बैटरी", "बैटरी कितनी है")) {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val st = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            return "बैटरी $pct% है" + (if (charging) ", चार्ज हो रही है 🔌" else " 🔋")
        }
        if (t in setOf("storage", "free storage", "storage kitna hai", "स्टोरेज", "स्टोरेज कितना है")) {
            val sf = StatFs(Environment.getDataDirectory().path)
            val free = sf.availableBytes / 1073741824.0
            val total = sf.totalBytes / 1073741824.0
            return "स्टोरेज में " + Calc.format(Math.round(free * 10) / 10.0) + " GB खाली है, कुल " + Calc.format(Math.round(total * 10) / 10.0) + " GB 💾"
        }
        if (t in setOf("ram", "free ram", "memory", "ram kitni free hai", "रैम", "रैम कितनी फ्री है")) {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            return "RAM में " + (mi.availMem / 1048576) + " MB खाली है, कुल " + (mi.totalMem / 1048576) + " MB 🧠"
        }

        // ---- fun ----
        if (t in setOf("joke", "joke sunao", "chutkula", "mazak", "जोक सुनाओ", "चुटकुला सुनाओ", "जोक")) return jokes.random()
        if (t in setOf("shayari", "shayari sunao", "शायरी सुनाओ", "शायरी")) return shayari.random()
        if (t in setOf("quote", "quote sunao", "motivation", "motivate me", "मोटिवेशन", "प्रेरणा", "कोई अच्छी बात")) return quotes.random()

        // ---- to-do list ----
        Regex("^(?:task add|todo add|add task|टास्क जोड़ो|काम जोड़ो) (.+)$").find(t)?.let {
            prefs.tasks = (prefs.tasks + "\n" + it.groupValues[1]).trim()
            return "टास्क जोड़ दिया ✅"
        }
        if (t in setOf("task list", "tasks", "todo list", "my tasks", "टास्क दिखाओ", "मेरे काम", "काम दिखाओ")) {
            val lines = prefs.tasks.lines().filter { it.isNotBlank() }
            return if (lines.isEmpty()) "अभी कोई टास्क नहीं है, $name।"
            else "तुम्हारे टास्क:\n" + lines.mapIndexed { i, s -> "" + (i + 1) + ". " + s }.joinToString("\n")
        }
        Regex("^(?:task done|done task|टास्क हो गया) (\\d+)$").find(t)?.let {
            val lines = prefs.tasks.lines().filter { l -> l.isNotBlank() }.toMutableList()
            val idx = it.groupValues[1].toInt() - 1
            if (idx in lines.indices) {
                val gone = lines.removeAt(idx)
                prefs.tasks = lines.joinToString("\n")
                return "शाबाश! \"" + gone + "\" हो गया 🎉"
            }
            return "ये नंबर लिस्ट में नहीं है, $name।"
        }
        if (t in setOf("task clear", "tasks clear", "टास्क मिटाओ")) {
            prefs.tasks = ""
            return "सारे टास्क मिटा दिए।"
        }

        // ---- focus timer ----
        if (t in setOf("pomodoro", "focus timer", "फोकस टाइमर", "पोमोडोरो")) {
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, 1500)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Nova focus: 25 मिनट पूरे, अब 5 मिनट आराम")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return try {
                ctx.startActivity(i)
                "25 मिनट का focus timer चालू 🍅 पूरा होने पर 5 मिनट आराम करना, $name।"
            } catch (e: Exception) {
                "Timer नहीं लग पाया, $name।"
            }
        }

        // ---- Gemini fast / smart ----
        if (t in setOf("gemini fast", "fast model", "जेमिनी फास्ट", "fast mode on", "turbo on", "turbo")) {
            prefs.turbo = true
            return "Gemini Fast चालू ⚡ अब हल्का और तेज़ model पहले चलेगा।"
        }
        if (t in setOf("gemini smart", "smart model", "जेमिनी स्मार्ट", "turbo off", "smart mode")) {
            prefs.turbo = false
            return "Gemini Smart चालू 🧠 अब बड़ा model पहले चलेगा, जवाब थोड़ा देर से पर ज़्यादा समझदार।"
        }

        // ---- unit converter ----
        Regex("^(?:convert )?(-?\\d+(?:\\.\\d+)?) ?([a-z]+) (?:to|in|se|में) ([a-z]+)$").find(t)?.let {
            val v = it.groupValues[1].toDouble()
            val a = unit(it.groupValues[2])
            val b = unit(it.groupValues[3])
            if (a != null && b != null) {
                val fa = lenFactor[a]
                val fb = lenFactor[b]
                val ma = massFactor[a]
                val mb = massFactor[b]
                val r: Double? = when {
                    a == "c" && b == "f" -> v * 9 / 5 + 32
                    a == "f" && b == "c" -> (v - 32) * 5 / 9
                    fa != null && fb != null -> v * fa / fb
                    ma != null && mb != null -> v * ma / mb
                    else -> null
                }
                if (r != null) return Calc.format(v) + " " + a + " = " + Calc.format(Math.round(r * 10000) / 10000.0) + " " + b
            }
        }
        // ---- percentage ----
        Regex("^(\\d+(?:\\.\\d+)?) ?% (?:of|का|की) (\\d+(?:\\.\\d+)?)$").find(t)?.let {
            val pct = it.groupValues[1].toDouble()
            val x = it.groupValues[2].toDouble()
            return Calc.format(pct) + "% of " + Calc.format(x) + " = " + Calc.format(Math.round(pct * x / 100.0 * 100) / 100.0)
        }

        // ---- EMI: emi <amount> <yearly rate %> <years> ----
        Regex("^emi (\\d+(?:\\.\\d+)?) (\\d+(?:\\.\\d+)?) (\\d+(?:\\.\\d+)?)$").find(t)?.let {
            val pr = it.groupValues[1].toDouble()
            val rate = it.groupValues[2].toDouble() / 12.0 / 100.0
            val n = it.groupValues[3].toDouble() * 12.0
            if (n >= 1) {
                val emi = if (rate == 0.0) pr / n else pr * rate * Math.pow(1 + rate, n) / (Math.pow(1 + rate, n) - 1)
                val total = emi * n
                return "हर महीने की EMI लगभग ₹" + Math.round(emi) + "\nकुल चुकाओगे लगभग ₹" + Math.round(total) +
                    " (ब्याज लगभग ₹" + Math.round(total - pr) + ") 🏦"
            }
        }

        // ---- BMI: bmi <kg> <cm> ----
        Regex("^bmi (\\d+(?:\\.\\d+)?) (\\d+(?:\\.\\d+)?)$").find(t)?.let {
            val kg = it.groupValues[1].toDouble()
            val cm = it.groupValues[2].toDouble()
            if (kg > 0 && cm > 0) {
                val m = cm / 100.0
                val bmi = kg / (m * m)
                val cat = when {
                    bmi < 18.5 -> "कम वज़न"
                    bmi < 25 -> "सामान्य"
                    bmi < 30 -> "थोड़ा ज़्यादा वज़न"
                    else -> "मोटापे की श्रेणी"
                }
                return "तुम्हारा BMI " + Calc.format(Math.round(bmi * 10) / 10.0) + " है: " + cat + " 💪 (ये सिर्फ़ मोटा अंदाज़ा है, डॉक्टर की सलाह नहीं)"
            }
        }

        // ---- days until a date / age ----
        Regex("^(?:days until|कितने दिन बचे) (\\d{4}-\\d{2}-\\d{2})$").find(t)?.let {
            try {
                val d = java.time.LocalDate.parse(it.groupValues[1])
                val days = java.time.temporal.ChronoUnit.DAYS.between(java.time.LocalDate.now(), d)
                return if (days >= 0) "उस तारीख में " + days + " दिन बाकी हैं 📆" else "वो तारीख " + (-days) + " दिन पहले बीत चुकी है।"
            } catch (e: Exception) {
                return "तारीख ऐसे लिखो: 2026-12-25"
            }
        }
        Regex("^(?:age|उम्र) (\\d{4}-\\d{2}-\\d{2})$").find(t)?.let {
            try {
                val b = java.time.LocalDate.parse(it.groupValues[1])
                val pd = java.time.Period.between(b, java.time.LocalDate.now())
                return "उम्र: " + pd.years + " साल, " + pd.months + " महीने, " + pd.days + " दिन 🎂"
            } catch (e: Exception) {
                return "तारीख ऐसे लिखो: 2001-05-14"
            }
        }

        // ---- text tools ----
        Regex("^(upper|reverse|wordcount|word count) (.+)$").find(t)?.let {
            val x = it.groupValues[2]
            return when (it.groupValues[1]) {
                "upper" -> x.uppercase()
                "reverse" -> x.reversed()
                else -> "शब्द: " + x.trim().split(Regex("\\s+")).size + ", अक्षर: " + x.length
            }
        }

        // ---- decision picker ----
        Regex("^(?:choose|pick|चुनो) (.+)$").find(t)?.let {
            val opts = it.groupValues[1].split(Regex(" or | या |,")).map { o -> o.trim() }.filter { o -> o.isNotEmpty() }
            if (opts.size >= 2) return "मैं चुनूँगी: " + opts.random() + " 🎯"
        }

        // ---- diary ----
        if (t in setOf("diary read", "journal read", "डायरी पढ़ो", "डायरी दिखाओ")) {
            val l = prefs.diary.lines().filter { it.isNotBlank() }.takeLast(5)
            return if (l.isEmpty()) "डायरी अभी खाली है।" else "तुम्हारी डायरी:\n" + l.joinToString("\n")
        }
        Regex("^(?:diary|journal|डायरी)[: ]+(.+)$").find(t)?.let {
            val stamp = SimpleDateFormat("d MMM, hh:mm a", Locale.getDefault()).format(Date())
            prefs.diary = (prefs.diary + "\n" + stamp + " — " + it.groupValues[1]).trim()
            return "डायरी में लिख लिया 📔"
        }

        // ---- password (copied, never spoken) ----
        Regex("^(?:password|password banao|generate password|पासवर्ड बनाओ)(?: (\\d{1,2}))?$").find(t)?.let {
            val len = (it.groupValues[1].toIntOrNull() ?: 12).coerceIn(8, 32)
            val pw = makePassword(len)
            try {
                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                    .setPrimaryClip(android.content.ClipData.newPlainText("nova password", pw))
            } catch (e: Exception) {
            }
            return "मज़बूत पासवर्ड बन गया और clipboard में कॉपी है 🔐 (मैं इसे बोलकर नहीं बताऊँगी, कहीं paste कर लो)"
        }
        return null
    }

    fun makePassword(len: Int): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#\$%&*?"
        val rnd = java.security.SecureRandom()
        return String(CharArray(len) { chars[rnd.nextInt(chars.length)] })
    }
}
